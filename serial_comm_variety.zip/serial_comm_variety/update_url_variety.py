# -*- coding: utf-8 -*-
"""
Created on Sun Jul 31 15:12:27 2022

@author: Michaela
"""

import urllib3
http = urllib3.PoolManager()

while True:
    print("Enter a key to move the robot")

    var = str(input())
    #print("You entered: ", var)
    
    if(var=='0'):
        print('Do Nothing')
        r = http.request('GET', 'https://slothy1.herokuapp.com/postCommand?command=0')        
    if(var=='1'):
        print('Move Forward')
        r = http.request('GET', 'https://slothy1.herokuapp.com/postCommand?command=1')
    elif(var=='2'):
        print('Move Backward')
        r = http.request('GET', 'https://slothy1.herokuapp.com/postCommand?command=2')
    elif(var=='3'):
        print('Dance 1')
        r = http.request('GET', 'https://slothy1.herokuapp.com/postCommand?command=3')
    elif(var=='4'):
        print('Dance 2')
        r = http.request('GET', 'https://slothy1.herokuapp.com/postCommand?command=4')